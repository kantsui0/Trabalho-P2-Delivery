# Raiz & Brasa — Painel de delivery

Trabalho P2 de Laboratório de Programação Front End.

## Integrantes
- CARLOS GABRIEL DE ARAUJO DA MOTTA
- YAGO TAVARES DE AQUINO

## Tecnologias
React, TypeScript, Vite, React Router, Context API e Axios.

## Como executar
1. Instale o Node.js.
2. Abra a pasta do projeto no VS Code.
3. No terminal, execute "npm install".
4. Confira se o arquivo ".env" contém "VITE_API_URL=https://dummyjson.com".
5. Execute "npm run dev" e abra o link mostrado no terminal.

## Build
Execute "npm run build".

## GitHub
https://github.com/kantsui0/Trabalho-P2-Delivery.git

## Login de teste
- Usuário: `emilys`
- Senha: `emilyspass`
