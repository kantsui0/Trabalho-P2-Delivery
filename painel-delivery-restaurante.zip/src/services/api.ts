import axios from 'axios'

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'https://dummyjson.com' })

export interface LoginResponse {
  accessToken: string
  refreshToken?: string
  id: number
  username: string
  firstName?: string
}

export async function loginRequest(username: string, password: string) {
  const { data } = await api.post<LoginResponse>('/auth/login', { username, password, expiresInMins: 60 })
  return data
}
export async function getCurrentUser(token: string) {
  const { data } = await api.get('/auth/me', { headers: { Authorization: `Bearer ${token}` } })
  return data
}
export async function getRecipes() {
  const { data } = await api.get('/recipes', { params: { limit: 30, select: 'id,name,cuisine,image,prepTimeMinutes,cookTimeMinutes' } })
  return data
}
export async function searchRecipes(query: string) {
  const { data } = await api.get('/recipes/search', { params: { q: query, limit: 30, select: 'id,name,cuisine,image,prepTimeMinutes,cookTimeMinutes' } })
  return data
}
export async function addRecipe(recipe: Omit<DishPayload, 'id'>) {
  const { data } = await api.post('/recipes/add', recipe)
  return data
}
export async function updateRecipe(id: number, recipe: Partial<DishPayload>) {
  const { data } = await api.patch(`/recipes/${id}`, recipe)
  return data
}
export async function deleteRecipe(id: number) {
  const { data } = await api.delete(`/recipes/${id}`)
  return data
}
export interface DishPayload {
  id: number
  name: string
  cuisine: string
  image: string
  prepTimeMinutes: number
  cookTimeMinutes: number
}
export function errorMessage(error: unknown): { status: number | null; message: string } {
  if (axios.isAxiosError(error)) {
    const status = error.response?.status ?? null
    const message = status ? `A API respondeu com status ${status}.` : 'Não foi possível conectar à API. Verifique sua internet.'
    return { status, message }
  }
  return { status: null, message: 'Ocorreu um erro inesperado.' }
}
