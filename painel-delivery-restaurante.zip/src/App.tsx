import { Navigate, Route, Routes } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import ProtectedRoute from './components/ProtectedRoute'
export default function App() {
  return <Routes>
    <Route path="/login" element={<Login/>}/>
    <Route element={<ProtectedRoute/>}><Route path="/" element={<Dashboard/>}/></Route>
    <Route path="*" element={<Navigate to="/" replace/>}/>
  </Routes>
}
