import { Clock3, Pencil, Trash2 } from 'lucide-react'
import type { Recipe } from '../types'
interface DishCardProps { dish: Recipe; onEdit: (dish: Recipe) => void; onDelete: (dish: Recipe) => void }
export function dishPrice(dish: Recipe) {
  return 15 + 0.5 * (dish.prepTimeMinutes + dish.cookTimeMinutes)
}
export default function DishCard({ dish, onEdit, onDelete }: DishCardProps) {
  return <article className="dish-card">
    <div className="dish-image-wrap"><img src={dish.image} alt={dish.name} onError={e => { e.currentTarget.src = 'https://placehold.co/600x400?text=Prato' }}/><span className="cuisine-tag">{dish.cuisine}</span></div>
    <div className="dish-info"><div><h3>{dish.name}</h3><p className="time"><Clock3 size={14}/> {dish.prepTimeMinutes + dish.cookTimeMinutes} min no total</p></div>
      <div className="dish-bottom"><strong>{dishPrice(dish).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</strong><div className="dish-actions"><button aria-label="Editar prato" onClick={() => onEdit(dish)}><Pencil size={16}/></button><button aria-label="Excluir prato" className="delete-btn" onClick={() => onDelete(dish)}><Trash2 size={16}/></button></div></div>
    </div>
  </article>
}
