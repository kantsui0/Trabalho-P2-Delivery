import { useEffect, useState, type FormEvent } from 'react'
import { X } from 'lucide-react'
import type { DishInput, Recipe } from '../types'
interface DishFormProps { dish: Recipe | null; onSave: (data: DishInput) => Promise<void>; onClose: () => void }
const empty: DishInput = { name: '', cuisine: '', prepTimeMinutes: 10, cookTimeMinutes: 15, image: 'https://cdn.dummyjson.com/recipe-images/1.webp' }
export default function DishForm({ dish, onSave, onClose }: DishFormProps) {
  const [form, setForm] = useState<DishInput>(empty)
  const [saving, setSaving] = useState(false)
  useEffect(() => {
    setForm(dish ? { name: dish.name, cuisine: dish.cuisine, prepTimeMinutes: dish.prepTimeMinutes, cookTimeMinutes: dish.cookTimeMinutes, image: dish.image } : empty)
  }, [dish])
  function change<K extends keyof DishInput>(key: K, value: DishInput[K]) { setForm(old => ({ ...old, [key]: value })) }
  async function submit(e: FormEvent) {
    e.preventDefault(); setSaving(true)
    try { await onSave(form) } finally { setSaving(false) }
  }
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}>
    <section className="modal"><div className="modal-head"><div><span className="eyebrow">{dish ? 'ATUALIZE O CARDÁPIO' : 'EXPANDA O CARDÁPIO'}</span><h2>{dish ? 'Editar prato' : 'Novo prato'}</h2></div><button className="icon-button" onClick={onClose}><X/></button></div>
      <form onSubmit={submit} className="dish-form">
        <label>Nome do prato<input required value={form.name} onChange={e => change('name', e.target.value)} placeholder="Ex.: Risoto de cogumelos"/></label>
        <label>Tipo de cozinha<input required value={form.cuisine} onChange={e => change('cuisine', e.target.value)} placeholder="Ex.: Brasileira"/></label>
        <label className="full-field">URL da foto<input required type="url" value={form.image} onChange={e => change('image', e.target.value)} placeholder="https://..."/></label>
        <label>Preparo (minutos)<input required type="number" min="0" value={form.prepTimeMinutes} onChange={e => change('prepTimeMinutes', Number(e.target.value))}/></label>
        <label>Cozimento (minutos)<input required type="number" min="0" value={form.cookTimeMinutes} onChange={e => change('cookTimeMinutes', Number(e.target.value))}/></label>
        <p className="price-hint full-field">O preço será calculado automaticamente pela regra do trabalho.</p>
        <div className="form-buttons full-field"><button type="button" className="secondary-btn" onClick={onClose}>Cancelar</button><button className="primary-btn" disabled={saving}>{saving ? 'Salvando...' : 'Salvar prato'}</button></div>
      </form>
    </section>
  </div>
}
