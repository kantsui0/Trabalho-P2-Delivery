import { ChefHat, LogOut, Utensils } from 'lucide-react'
interface HeaderProps { restaurantName: string; userName: string; onLogout: () => void }
export default function Header({ restaurantName, userName, onLogout }: HeaderProps) {
  return <header className="topbar">
    <div className="brand"><span className="brand-icon"><ChefHat size={22}/></span><span>{restaurantName}<small>PAINEL DO RESTAURANTE</small></span></div>
    <div className="top-actions"><span className="welcome"><Utensils size={15}/> Olá, {userName}</span><button className="logout" onClick={onLogout}><LogOut size={16}/> Sair</button></div>
  </header>
}
