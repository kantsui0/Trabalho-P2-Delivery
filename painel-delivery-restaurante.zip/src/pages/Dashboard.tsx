import { useEffect, useMemo, useState } from 'react'
import { Plus, Search, UtensilsCrossed } from 'lucide-react'
import Header from '../components/Header'
import DishCard from '../components/DishCard'
import DishForm from '../components/DishForm'
import { useAuth } from '../context/AuthContext'
import { addRecipe, deleteRecipe, errorMessage, getRecipes, updateRecipe } from '../services/api'
import type { DishInput, Recipe, RecipesResponse } from '../types'
export default function Dashboard() {
  const { user, signOut } = useAuth()
  const [dishes, setDishes] = useState<Recipe[]>([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [status, setStatus] = useState<number | null>(null)
  const [selected, setSelected] = useState<Recipe | null>(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [notice, setNotice] = useState('')
  useEffect(() => {
    let active = true
    async function load() {
      setLoading(true); setError('')
      try { const data = await getRecipes() as RecipesResponse; if (active) setDishes(data.recipes) }
      catch (err) { const info = errorMessage(err); if (active) { setError(info.message); setStatus(info.status) } }
      finally { if (active) setLoading(false) }
    }
    load()
    return () => { active = false }
  }, [])
  const filtered = useMemo(() => dishes.filter(d => d.name.toLocaleLowerCase('pt-BR').includes(query.toLocaleLowerCase('pt-BR'))), [dishes, query])
  async function saveDish(data: DishInput) {
    setError(''); setNotice('')
    const payload = { ...data, image: data.image }
    try {
      if (selected) {
        await updateRecipe(selected.id, payload)
        setDishes(old => old.map(d => d.id === selected.id ? { ...d, ...payload } : d))
        setNotice('Prato atualizado no cardápio.')
      } else {
        await addRecipe(payload)
        setDishes(old => [{ ...payload, id: 51 }, ...old])
        setNotice('Prato cadastrado no cardápio.')
      }
      setModalOpen(false); setSelected(null)
    } catch (err) {
      const info = errorMessage(err); setStatus(info.status); setError(info.message)
    }
  }
  async function removeDish(dish: Recipe) {
    if (!window.confirm(`Deseja realmente excluir "${dish.name}"?`)) return
    setError(''); setNotice('')
    try {
      await deleteRecipe(dish.id)
      setDishes(old => old.filter(d => d.id !== dish.id))
      setNotice('Prato removido do cardápio.')
    } catch (err) {
      const info = errorMessage(err); setStatus(info.status)
      setError(dish.id === 51 ? 'A API não permite editar ou excluir o prato criado (ID 51). Ele continua nesta sessão, mas não foi removido.' : info.message)
    }
  }
  return <div className="dashboard"><Header restaurantName="Raiz & Brasa" userName={user?.firstName || user?.username || 'parceiro'} onLogout={signOut}/>
    <main className="main-content"><section className="welcome-row"><div><span className="eyebrow">GESTÃO DO RESTAURANTE</span><h1>Seu cardápio</h1><p>Gerencie os sabores que chegam à mesa dos seus clientes.</p></div><button className="primary-btn add-button" onClick={() => { setSelected(null); setModalOpen(true) }}><Plus size={18}/> Novo prato</button></section>
      <section className="toolbar"><div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Buscar prato pelo nome..."/></div><span className="dish-count">{filtered.length} {filtered.length === 1 ? 'prato' : 'pratos'}</span></section>
      {notice && <div className="alert success">{notice}</div>}
      {error && <div className="alert error">{error}{status && <span> (status HTTP {status})</span>}</div>}
      {loading ? <div className="state-box"><span className="spinner"/><p>Carregando cardápio...</p></div> :
       filtered.length ? <div className="dish-grid">{filtered.map(dish => <DishCard key={dish.id} dish={dish} onEdit={d => { setSelected(d); setModalOpen(true) }} onDelete={removeDish}/>)}</div> :
       <div className="state-box empty"><UtensilsCrossed size={34}/><h3>{query ? 'Nenhum prato encontrado' : 'Seu cardápio está vazio'}</h3><p>{query ? 'Tente buscar por outro nome.' : 'Cadastre seu primeiro prato para começar.'}</p></div>}
    </main>
    {modalOpen && <DishForm dish={selected} onSave={saveDish} onClose={() => { setModalOpen(false); setSelected(null) }}/>}
  </div>
}
