import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChefHat, LockKeyhole, UserRound } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { errorMessage } from '../services/api'
export default function Login() {
  const [username, setUsername] = useState('emilys')
  const [password, setPassword] = useState('emilyspass')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { signIn } = useAuth()
  const navigate = useNavigate()
  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setLoading(true)
    try { await signIn(username, password); navigate('/', { replace: true }) }
    catch (err) { const info = errorMessage(err); setError(`${info.message} Confira usuário e senha.`) }
    finally { setLoading(false) }
  }
  return <main className="login-page"><div className="login-art"><div className="art-content"><div className="brand brand-light"><span className="brand-icon"><ChefHat size={24}/></span><span>Raiz & Brasa<small>COZINHA COM AFETO</small></span></div><div className="art-copy"><span className="eyebrow">SEU RESTAURANTE, SEU JEITO</span><h1>O sabor da sua cozinha começa por aqui.</h1><p>Gerencie seu cardápio com praticidade, de qualquer lugar.</p></div><span className="art-footer">SIMPLES • FRESCO • FEITO COM CUIDADO</span></div></div>
    <section className="login-panel"><form className="login-form" onSubmit={submit}><div className="mobile-logo"><ChefHat size={30}/><b>Raiz & Brasa</b></div><span className="eyebrow">ÁREA DO PARCEIRO</span><h2>Boas-vindas!</h2><p className="muted">Entre para administrar seu restaurante.</p>
      <label>Usuário<div className="input-icon"><UserRound size={17}/><input value={username} onChange={e => setUsername(e.target.value)} autoComplete="username" required/></div></label>
      <label>Senha<div className="input-icon"><LockKeyhole size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required/></div></label>
      {error && <div className="alert error">{error}</div>}
      <button className="primary-btn login-submit" disabled={loading}>{loading ? 'Entrando...' : 'Entrar no painel'}</button>
      <div className="test-login"><b>Conta de teste</b><span>Usuário: emilys</span><span>Senha: emilyspass</span></div>
    </form><span className="login-legal">PAINEL ADMINISTRATIVO • RAIZ & BRASA</span></section>
  </main>
}
