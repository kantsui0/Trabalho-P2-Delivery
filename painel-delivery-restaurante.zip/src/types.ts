export interface Recipe {
  id: number
  name: string
  cuisine: string
  image: string
  prepTimeMinutes: number
  cookTimeMinutes: number
}
export interface RecipesResponse {
  recipes: Recipe[]
  total: number
  skip: number
  limit: number
}
export interface DishInput {
  name: string
  cuisine: string
  prepTimeMinutes: number
  cookTimeMinutes: number
  image: string
}
