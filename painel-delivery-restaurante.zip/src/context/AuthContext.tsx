import { createContext, useContext, useMemo, useState, type ReactNode } from 'react'
import { loginRequest, type LoginResponse } from '../services/api'

interface AuthContextValue {
  user: LoginResponse | null
  token: string | null
  signIn: (username: string, password: string) => Promise<void>
  signOut: () => void
}
const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('delivery_token'))
  const [user, setUser] = useState<LoginResponse | null>(() => {
    const saved = localStorage.getItem('delivery_user')
    return saved ? JSON.parse(saved) as LoginResponse : null
  })

  async function signIn(username: string, password: string) {
    const data = await loginRequest(username, password)
    setToken(data.accessToken)
    setUser(data)
    localStorage.setItem('delivery_token', data.accessToken)
    localStorage.setItem('delivery_user', JSON.stringify(data))
  }
  function signOut() {
    setToken(null); setUser(null)
    localStorage.removeItem('delivery_token'); localStorage.removeItem('delivery_user')
  }
  const value = useMemo(() => ({ user, token, signIn, signOut }), [user, token])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth deve ser usado dentro de AuthProvider')
  return context
}
