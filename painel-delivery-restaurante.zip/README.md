# Raiz & Brasa — Painel de delivery

Projeto acadêmico desenvolvido para o Trabalho P2 de Laboratório de Programação Front End.

## Integrantes
- NOME COMPLETO DO(A) INTEGRANTE 1
- NOME COMPLETO DO(A) INTEGRANTE 2

## Tecnologias
React, TypeScript, Vite, React Router, Context API e Axios.

## Como executar
1. Instale o Node.js (versão LTS).
2. Abra a pasta do projeto no VS Code.
3. No terminal, execute `npm install`.
4. Confira se o arquivo `.env` contém `VITE_API_URL=https://dummyjson.com`.
5. Execute `npm run dev` e abra o endereço mostrado no terminal.

## Build
Execute `npm run build`.

## GitHub
COLE_AQUI_O_LINK_DO_REPOSITORIO

## Login de teste
- Usuário: `emilys`
- Senha: `emilyspass`

## Observação sobre a API
O DummyJSON simula operações de criação, edição e exclusão. As alterações são mantidas no estado local enquanto a aplicação está aberta. Ao recarregar, a lista original da API volta a aparecer.
